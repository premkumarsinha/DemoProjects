package com.maveric.spectrum.entities;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

@Embeddable
@Data
public class UserSkillKey implements Serializable{

	@Column(name="employee_id",nullable = false)
	private Integer employeeId;
	@Column(name="skill_id",nullable = true)
	private Integer skillId;
}
