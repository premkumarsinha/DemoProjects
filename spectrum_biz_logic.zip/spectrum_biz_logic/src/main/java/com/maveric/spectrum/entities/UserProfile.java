package com.maveric.spectrum.entities;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="user_profile")
public class UserProfile {
	
	@Id
	@Column(name="employee_id")
	private Integer employeeId;
	@Column(name="reporting_manager",length = 50,nullable = false)
	private String reportingManager;
	@Column(name="email_address",length = 50,nullable = false)
	private String emailAddress;
	@Column(name="designation",length = 50,nullable = false)
	private String designation;
	@Column(name="about_me",columnDefinition = "TEXT",length = 1000)
	private String aboutMe;
	@Enumerated(EnumType.STRING)
	@Column(name="role",nullable = false)
	private Role role;
	
	
	@OneToMany(mappedBy = "user")
	private List<UserCertificate> certifications;
	
	@OneToMany(mappedBy = "user")
	private List<Qualification> qualifications;
	
	@OneToMany(mappedBy = "user")
	private List<Project> projects;
	
	@OneToMany(mappedBy = "user")
    private List<UserSkill> userSkill;

}
