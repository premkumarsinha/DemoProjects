package com.maveric.spectrum.entities;

public enum Role {
	USER,
	MANAGER,
	SUPERUSER
}
