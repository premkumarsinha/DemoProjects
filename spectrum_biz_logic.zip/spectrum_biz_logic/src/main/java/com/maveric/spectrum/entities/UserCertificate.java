package com.maveric.spectrum.entities;



import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="user_certificate")
public class UserCertificate {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="certificate_id")
	private Integer certificateId;
	
	@Column(name="certification_name",length = 50,nullable = false)
	private String certificationName;
	@Column(name="issuing_organization",length = 50,nullable = false)
	private String issuingOrganization;
	@Column(name="issuing_date",nullable = false)
	private Date issuingDate;
	@Column(name="expiration_date",nullable = false)
	private Date expirationDate;
	
	@ManyToOne
	@JoinColumn(name = "employee_id",nullable = false)
	private UserProfile user;
}
