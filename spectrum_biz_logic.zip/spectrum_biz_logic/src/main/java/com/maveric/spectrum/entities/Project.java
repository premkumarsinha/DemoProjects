package com.maveric.spectrum.entities;



import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="project_experience")
public class Project {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="project_id")
	private Integer projectId;
	
	@Column(name="project_title",length = 50,nullable = false)
	private String projectTitle;
	@Column(name="role",length = 45,nullable = false)
	private String role;
	@Column(name="description",columnDefinition = "TEXT",length = 1000)
	private String description;
	@Column(name="reponsibility",columnDefinition = "TEXT",length = 1000)
	private String responsibilty;
	@Column(name="start_duration",nullable = false)
	private Date startDuration;
	@Column(name="end_duration",nullable = false)
	private Date endDuration;
	
	@ManyToOne
	@JoinColumn(name="employee_id",nullable = false)
	private UserProfile user;

}
