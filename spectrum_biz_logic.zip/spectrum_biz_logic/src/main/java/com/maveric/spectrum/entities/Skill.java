package com.maveric.spectrum.entities;

import java.util.List;

import org.hibernate.annotations.ManyToAny;

import jakarta.annotation.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "skill")
public class Skill {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="skill_id")
	private Integer skillId;
	
	@Column(name="skill_name",length = 50,nullable = false)
	private String skillName;
	
	@ManyToOne
	@JoinColumn(name="cluster_id", nullable=false)
	private SkillCluster skillCluster;
	
	@OneToMany(mappedBy = "skill")
	private List<Tools> tools;
	
	@OneToMany(mappedBy = "skill")
    private List<UserSkill> userSkill;

}
