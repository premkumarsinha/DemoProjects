package com.maveric.spectrum.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="unclassified_skills")
public class UnclassifiedSkills {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="skill_id")
	private Integer skillId;
	
	@Column(name="skill_name",length = 50)
	private String skillName;
}
