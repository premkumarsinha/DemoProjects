package com.maveric.spectrum.entities;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="user_skill_mapping")
public class UserSkill {
	
	@EmbeddedId
	private UserSkillKey id;
	
	@ManyToOne
    @MapsId("employeeId")
    @JoinColumn(name = "employee_id")
    private UserProfile user;

    @ManyToOne
    @MapsId("skillId")
    @JoinColumn(name = "skill_id")
    private Skill skill;
    
    @Column(name="skill_name",length = 50,nullable = false)
    private String skillName;
    @Column(name="proficiency_level",length = 50)
    private String proficiencyLevel;
	
	

}
