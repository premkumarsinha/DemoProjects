package com.maveric.spectrum.entities;



import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="qualification")
public class Qualification {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="qualification_id")
	private Integer qualificationId; 
	@Column(name="qualification_title",length = 50,nullable = false)
	private String qualificationTitle;
	@Column(name="institution_name",length = 50,nullable = false)
	private String institutionName;
	@Column(name="place",length = 50)
	private String place;
	@Column(name="start_duration",nullable = false)
	private Date startDuration;
	@Column(name="end_duration",nullable = false)
	private Date endDuration;
	@Column(name="score",nullable = false)
	private Double score;
	
	@ManyToOne
	@JoinColumn(name = "employee_id",nullable = false)
	private UserProfile user;
	
}
