package com.maveric.spectrum.entities;

import java.util.List;

import jakarta.annotation.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "skill_cluster")
public class SkillCluster {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "skill_cluster_id")
	private Integer clusterId;
	
	@Column(name = "cluster_name",length = 50,nullable = false)
	private String clusterName;
	
	@OneToMany(mappedBy = "skillCluster")
	private List<Skill> skills;
}
