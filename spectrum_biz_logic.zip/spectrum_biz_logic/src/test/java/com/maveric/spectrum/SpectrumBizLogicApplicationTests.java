package com.maveric.spectrum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpectrumBizLogicApplicationTests {

	@Test
	void contextLoads() {
	}

}
