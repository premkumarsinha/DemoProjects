package com.maveric.payroll;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.maveric.payroll.daos.EmployeeDao;
import com.maveric.payroll.daos.SalaryDao;
import com.maveric.payroll.daos.SalaryDaoImpl;
import com.maveric.payroll.entities.Employee;
import com.maveric.payroll.entities.Salary;
import com.maveric.payroll.entities.SalaryAccount;
import com.maveric.payroll.exception.EmployeeDetailsNotFoundException;
import com.maveric.payroll.exception.SalaryDetailsNotFoundException;
import com.maveric.payroll.services.PayrollService;
import com.maveric.payroll.services.PayrollServiceImpl;

class PayrollServiceTest {

	private static PayrollService payrollservice;
	private static EmployeeDao mockemployeedao;
	private static SalaryDao mocksalarydao;
	
	@BeforeAll
	static void setUptTestEnv()
	{
		
		mockemployeedao=Mockito.mock(EmployeeDao.class);
		mocksalarydao=Mockito.mock(SalaryDao.class);
		payrollservice=new PayrollServiceImpl(mockemployeedao,mocksalarydao);
	}
	
	@BeforeEach
	void setUpTestMockDataEnv() {
		Employee mockEmployee1 = new Employee(11,100000,30000,"Prem Kumar Sinha","SDE1","hsgds1","hdd23","2023-09-20","2023-01-29",new ArrayList<Salary>(),new SalaryAccount(123,"ICICI","ICIC1872"));
		Employee mockEmployee2 = new Employee(22,50000,20000,"Jai Prakash Sinha","Trainer","hjhgfer","ugf56","2021-07-12","2020-09-29",new ArrayList<Salary>(),new SalaryAccount(124,"ICICI","ICIC1772"));
//		Employee mockEmployee4 = new Employee(111,143200,30000,"Prem Kumar Sinha","SDE1","hsgds1","hdd23","2023-09-20","2023-01-29",new ArrayList<Salary>(),new SalaryAccount(123,"ICICI","ICIC1872"));
		
		Employee mockEmployee3 = new Employee(77,80000,20000,"Meena Sinha","Manager","hsgvwv","h7323","2023-05-20","2023-11-29",new ArrayList<Salary>(),new SalaryAccount(125,"HDFC","HDFC1772"));
		Salary mockSalary=new Salary(9000,9000,9000,49450,3550,3600,2,"Jan");
		Mockito.when(mockemployeedao.getEmployeeByNo(11)).thenReturn(Optional.of(mockEmployee1));
		Mockito.when(mockemployeedao.getEmployeeByNo(22)).thenReturn(Optional.of(mockEmployee2));
//		Mockito.when(mockemployeedao.getEmployeeByNo(111)).thenReturn(Optional.of(mockEmployee4));
		Mockito.when(mockemployeedao.getEmployeeByNo(555)).thenReturn(Optional.ofNullable(null));
		Mockito.when(mockemployeedao.getEmployeeByNo(777)).thenReturn(Optional.ofNullable(null));
		Mockito.when(mockemployeedao.save(new Employee("Jai Prakash Sinha","Trainer","hjhgfer","ugf56","2021-07-12","2020-09-29",50000,20000,new SalaryAccount(124,"ICICI","ICIC1772"),new ArrayList<Salary>()))).thenReturn(mockEmployee2);
		Mockito.when(mocksalarydao.getSalaryDetails(22, "Jan")).thenReturn(Optional.ofNullable(mockSalary));
		Mockito.when(mocksalarydao.getSalaryDetails(22, "Feb")).thenReturn(Optional.ofNullable(null));
		Mockito.when(mocksalarydao.addSalary(mockSalary, 11)).thenReturn(mockSalary);
	}
	
	@Test
	void test() {
		Assertions.assertThrows(EmployeeDetailsNotFoundException.class, ()->payrollservice.getEmployeeDetails(777));
		Mockito.verify(mockemployeedao ,times(1)).getEmployeeByNo(777);
	}
	
	@Test
	void test1() {
		Assertions.assertThrows(SalaryDetailsNotFoundException.class, ()->payrollservice.getEmployeeSalaryDetails(22,"Feb"));
		Mockito.verify(mocksalarydao ,times(1)).getSalaryDetails(22, "Feb");
	}
	
	@Test
void test2() throws EmployeeDetailsNotFoundException {
		
		Employee expectedEmployee = new Employee(11,100000,30000,"Prem Kumar Sinha","SDE1","hsgds1","hdd23","2023-09-20","2023-01-29",new ArrayList<Salary>(),new SalaryAccount(123,"ICICI","ICIC1872"));
		Employee actualEmployee = payrollservice.getEmployeeDetails(11);
		Assertions.assertEquals(expectedEmployee, actualEmployee);   //  ==  || equals()   ---->  
		Mockito.verify(mockemployeedao ,times(1)).getEmployeeByNo(11);
		
	}
	@Test
	void test3 ()
	{
		Employee expectedOutcome=new Employee(22,50000,20000,"Jai Prakash Sinha","Trainer","hjhgfer","ugf56","2021-07-12","2020-09-29",new ArrayList<Salary>(),new SalaryAccount(124,"ICICI","ICIC1772"));
		Employee actualOutput=payrollservice.createEmployee("Jai Prakash Sinha","Trainer","hjhgfer","ugf56","2021-07-12","2020-09-29",50000,20000,new SalaryAccount(124,"ICICI","ICIC1772"),new ArrayList<Salary>());
		Assertions.assertEquals(expectedOutcome, actualOutput);
		Mockito.verify(mockemployeedao ,times(1)).save(new Employee("Jai Prakash Sinha","Trainer","hjhgfer","ugf56","2021-07-12","2020-09-29",50000,20000,new SalaryAccount(124,"ICICI","ICIC1772"),new ArrayList<Salary>()));
	}
	
	@Test
	void test4() throws SalaryDetailsNotFoundException, EmployeeDetailsNotFoundException
	{
		Salary expectedOutcome=new Salary(9000,9000,9000,49450,3550,3600,2,"Jan");
		Salary actualOutput=payrollservice.getEmployeeSalaryDetails(22,"Jan");
		Assertions.assertEquals(expectedOutcome, actualOutput);
		Mockito.verify(mocksalarydao ,times(1)).getSalaryDetails(22,"Jan");
	}
	
	@Test
	void test5() throws EmployeeDetailsNotFoundException
	{
		double expectedOutcome=49450;
		double actualOutput=payrollservice.calculateMonthNetSalary(11,"Jan",2);
		Salary mockSalary=new Salary(9000,9000,9000,49450,3550,3600,2,"Jan");
		Assertions.assertEquals(expectedOutcome, actualOutput);
		Mockito.verify(mocksalarydao ,times(1)).addSalary(mockSalary, 11);
	}
	
	@AfterAll
	public static void tearDownPayrollServices() {
		mockemployeedao = null;
		payrollservice = null;
	}
}
