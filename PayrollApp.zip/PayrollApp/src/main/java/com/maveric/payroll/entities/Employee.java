package com.maveric.payroll.entities;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Employee {
	
	private int id;
	private double investmentUnder80C,basicPay;
	private String name,designation,pfNo,pancardNo;
	private String DOJ,DOB;
	private ArrayList<Salary> salaries;
	private SalaryAccount salaryAccount;
	public int getId() {
		return id;
	}
	public double getBasicPay() {
		return basicPay;
	}
	public void setBasicPay(double basicPay) {
		this.basicPay = basicPay;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPfNo() {
		return pfNo;
	}
	public void setPfNo(String pfNo) {
		this.pfNo = pfNo;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getDOJ() {
		return DOJ;
	}
	public void setDOJ(String dOJ) {
		DOJ = dOJ;
	}
	public String getDOB() {
		return DOB;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", investmentUnder80C=" + investmentUnder80C + ", name=" + name + ", designation="
				+ designation + ", pfNo=" + pfNo + ", pancardNo=" + pancardNo + ", DOJ=" + DOJ + ", DOB=" + DOB
				+ ", salaries=" + salaries + ", salaryAccount=" + salaryAccount + ", basicPay="+basicPay+"]";
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public Employee(String name, String designation, String pfNo, String pancardNo,
			String dOJ, String dOB,double investmentUnder80C,double basicPay, SalaryAccount salaryAccount,ArrayList<Salary> salary) {
		super();
	
		this.name = name;
		this.designation = designation;
		this.pfNo = pfNo;
		this.pancardNo = pancardNo;
		DOJ = dOJ;
		DOB = dOB;
		this.basicPay=basicPay;
		this.investmentUnder80C=investmentUnder80C+12*(0.12*basicPay);
		this.salaryAccount=salaryAccount;
		salaries=salary;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public double getInvestmentUnder80C() {
		return investmentUnder80C;
	}
	public void setInvestmentUnder80C(double investmentUnder80C) {
		this.investmentUnder80C = investmentUnder80C;
	}
	public List<Salary> getSalaries() {
		return salaries;
	}
	public void setSalaries(ArrayList<Salary> salaries) {
		this.salaries = salaries;
	}
	public SalaryAccount getSalaryAccount() {
		return salaryAccount;
	}
	public void setSalaryAccount(SalaryAccount salaryAccount) {
		this.salaryAccount = salaryAccount;
	}
	public Employee(int id, double investmentUnder80C, double basicPay, String name, String designation, String pfNo,
			String pancardNo, String dOJ, String dOB, ArrayList<Salary> salaries, SalaryAccount salaryAccount) {
		super();
		this.id = id;
		this.investmentUnder80C = investmentUnder80C;
		this.basicPay = basicPay;
		this.name = name;
		this.designation = designation;
		this.pfNo = pfNo;
		this.pancardNo = pancardNo;
		DOJ = dOJ;
		DOB = dOB;
		this.salaries = salaries;
		this.salaryAccount = salaryAccount;
	}
	@Override
	public int hashCode() {
		return Objects.hash(DOB, DOJ, basicPay, designation, id, investmentUnder80C, name, pancardNo, pfNo, salaries,
				salaryAccount);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(DOB, other.DOB) && Objects.equals(DOJ, other.DOJ)
				&& Double.doubleToLongBits(basicPay) == Double.doubleToLongBits(other.basicPay)
				&& Objects.equals(designation, other.designation) && id == other.id
				&& Double.doubleToLongBits(investmentUnder80C) == Double.doubleToLongBits(other.investmentUnder80C)
				&& Objects.equals(name, other.name) && Objects.equals(pancardNo, other.pancardNo)
				&& Objects.equals(pfNo, other.pfNo) && Objects.equals(salaries, other.salaries)
				&& Objects.equals(salaryAccount, other.salaryAccount);
	}
	
	
	
	
}
