package com.maveric.payroll.entities;

import java.util.Objects;

public class Salary {

	private double hra, ta, da,netSalary, monthlyTax,pfAmt;

	private int noOfLeaves;
	private String month;
	public Salary() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Salary(double hra, double ta, double da, double netSalary, double monthlyTax,
			int noOfLeaves, String month) {
		super();
		this.hra = hra;
		this.ta = ta;
		this.da = da;
		this.netSalary = netSalary;
		this.monthlyTax = monthlyTax;
		this.noOfLeaves = noOfLeaves;
		this.month = month;
	}
	
	
	public Salary(double hra, double ta, double da, double netSalary, double monthlyTax, double pfAmt, int noOfLeaves,
			String month) {
		super();
		this.hra = hra;
		this.ta = ta;
		this.da = da;
		this.netSalary = netSalary;
		this.monthlyTax = monthlyTax;
		this.pfAmt = pfAmt;
		this.noOfLeaves = noOfLeaves;
		this.month = month;
	}
	public double getPfAmt() {
		return pfAmt;
	}
	public void setPfAmt(double pfAmt) {
		this.pfAmt = pfAmt;
	}
	
	public double getHra() {
		return hra;
	}
	public void setHra(double hra) {
		this.hra = hra;
	}
	public double getTa() {
		return ta;
	}
	public void setTa(double ta) {
		this.ta = ta;
	}
	public double getDa() {
		return da;
	}
	public void setDa(double da) {
		this.da = da;
	}
	public double getNetSalary() {
		return netSalary;
	}
	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}
	public double getMonthlyTax() {
		return monthlyTax;
	}
	public void setMonthlyTax(double monthlyTax) {
		this.monthlyTax = monthlyTax;
	}
	public int getNoOfLeaves() {
		return noOfLeaves;
	}
	public void setNoOfLeaves(int noOfLeaves) {
		this.noOfLeaves = noOfLeaves;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	@Override
	public String toString() {
		return "Salary [hra=" + hra + ", ta=" + ta + ", da=" + da + ", netSalary="
				+ netSalary + ", monthlyTax=" + monthlyTax + ", noOfLeaves=" + noOfLeaves + ", month=" + month + ", pfAmount="+ pfAmt+"]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(da, hra, month, monthlyTax, netSalary, noOfLeaves, pfAmt, ta);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Salary other = (Salary) obj;
		return Double.doubleToLongBits(da) == Double.doubleToLongBits(other.da)
				&& Double.doubleToLongBits(hra) == Double.doubleToLongBits(other.hra)
				&& Objects.equals(month, other.month)
				&& Double.doubleToLongBits(monthlyTax) == Double.doubleToLongBits(other.monthlyTax)
				&& Double.doubleToLongBits(netSalary) == Double.doubleToLongBits(other.netSalary)
				&& noOfLeaves == other.noOfLeaves
				&& Double.doubleToLongBits(pfAmt) == Double.doubleToLongBits(other.pfAmt)
				&& Double.doubleToLongBits(ta) == Double.doubleToLongBits(other.ta);
	}

	
	
	
}
