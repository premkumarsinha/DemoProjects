package com.maveric.payroll.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.maveric.payroll.entities.Employee;
import com.maveric.payroll.entities.Salary;
import com.maveric.payroll.entities.SalaryAccount;
import com.maveric.payroll.exception.EmployeeDetailsNotFoundException;
import com.maveric.payroll.exception.SalaryDetailsNotFoundException;

public interface PayrollService {


	Employee getEmployeeDetails(int no)throws EmployeeDetailsNotFoundException;
	
	Salary getEmployeeSalaryDetails(int no,String month)throws SalaryDetailsNotFoundException, EmployeeDetailsNotFoundException;
	
	//Salary [] getEmployeeSalariesDetails(int no)throws EmployeeDetailsNotFoundException;
	
	double calculateMonthNetSalary(int id,String month,int noOfLeaves)throws EmployeeDetailsNotFoundException;

	

	Employee createEmployee(String name, String designation, String pfNo, String pancardNo, String dOJ,
			String dOB, double investmentUnder80C,double basicPay,SalaryAccount salaryAccount,ArrayList<Salary> salary) ;
}
