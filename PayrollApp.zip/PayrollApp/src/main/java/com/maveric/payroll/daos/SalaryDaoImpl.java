package com.maveric.payroll.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import com.maveric.payroll.entities.Salary;
import com.maveric.payroll.utils.DBUtil;

public class SalaryDaoImpl implements SalaryDao {

	Connection con;
	
	
	public SalaryDaoImpl() {
		con=DBUtil.getConn();
	}


	@Override
	public Salary addSalary(Salary sal, int i) {
		
		try {
			PreparedStatement pr=con.prepareStatement("insert into salary values(?,?,?,?,?,?,?,?,?)");
			pr.setDouble(1,sal.getHra());
			pr.setDouble(2,sal.getTa());
			pr.setDouble(3,sal.getDa());
			pr.setDouble(4,sal.getNetSalary());
			pr.setDouble(5,sal.getPfAmt());
			pr.setDouble(6,sal.getMonthlyTax());
			pr.setInt(7,sal.getNoOfLeaves());
			pr.setString(8,sal.getMonth());
			pr.setInt(9,i);
			
			int rowsAffected=pr.executeUpdate();
			
			
			System.out.println(rowsAffected+" rows are affected");
			return sal;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public Optional<Salary> getSalaryDetails(int id, String month) {
		
		Salary sal=new Salary();
		try {
		PreparedStatement pr=con.prepareStatement("select hra,ta,da,net_salary,pf_amount,tax_amount,no_of_leaves,month from salary where employee_id=? and month=?");
		pr.setInt(1, id);
		pr.setString(2, month);
		ResultSet res=pr.executeQuery();
		if(res.next())
		{
			sal.setHra(res.getDouble(1));
			sal.setTa(res.getDouble(2));
			sal.setDa(res.getDouble(3));
			sal.setNetSalary(res.getDouble(4));
			sal.setPfAmt(res.getDouble(5));
			sal.setMonthlyTax(res.getDouble(6));
			sal.setNoOfLeaves(res.getInt(7));
			sal.setMonth(res.getString(8));
			
			return Optional.ofNullable(sal);
		}
		else
			Optional.empty();
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return Optional.ofNullable(null);
	}

}
