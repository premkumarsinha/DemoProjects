package com.maveric.payroll.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.maveric.payroll.entities.SalaryAccount;
import com.maveric.payroll.utils.DBUtil;

public class SalaryAccountDaoImpl implements SalaryAccountDao {

	Connection con;
	
	public SalaryAccountDaoImpl() {
		con=DBUtil.getConn();
	}


	@Override
	public SalaryAccount getSalaryAccount(int id) {
		try {
			PreparedStatement ps=con.prepareStatement("select account_no,bank_name,ifsc_code from salary_account where employee_id="+id);
			ResultSet rs=ps.executeQuery();
			rs.next();
			return new SalaryAccount(rs.getLong(1),rs.getString(2),rs.getString(3));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
