package com.maveric.payroll.main;

import java.util.ArrayList;

import com.maveric.payroll.entities.Employee;
import com.maveric.payroll.services.PayrollService;
import com.maveric.payroll.services.PayrollServiceImpl;
import com.maveric.payroll.utils.DBUtil;
import com.maveric.payroll.entities.Salary;
import com.maveric.payroll.entities.SalaryAccount;
import com.maveric.payroll.exception.EmployeeDetailsNotFoundException;
import com.maveric.payroll.exception.SalaryDetailsNotFoundException;

public class MainClass {

	public static void main(String[] args) {
		DBUtil dbutil=new DBUtil();
		
//		PayrollService ps=new PayrollServiceImpl();
//		System.out.println(ps.createEmployee("Prem Kumar Sinha","SDE1","1782did8","grvcd123" , "2023-09-11","1998-01-29", 100000, 30000,new SalaryAccount(9876543,"ICICI","ICIC234"), null));
		
//		try {
//			System.out.print(ps.getEmployeeDetails(2));
//		} catch (EmployeeDetailsNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
//		try {
//			ps.calculateMonthNetSalary(1, "Jan", 2);
//		} catch (EmployeeDetailsNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
//		try {
//			System.out.print(ps.getEmployeeSalaryDetails(1, "Jan"));
//		} catch (EmployeeDetailsNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (SalaryDetailsNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}


}
