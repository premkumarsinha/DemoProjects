package com.maveric.payroll.daos;

import java.sql.Connection;
import java.util.List;
import java.util.Optional;

import com.maveric.payroll.entities.Salary;

public interface SalaryDao {
	
	
	public Salary addSalary(Salary sal,int i);
	
	public Optional<Salary> getSalaryDetails(int id,String month);
}
