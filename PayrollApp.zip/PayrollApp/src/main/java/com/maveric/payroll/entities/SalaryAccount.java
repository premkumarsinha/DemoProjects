package com.maveric.payroll.entities;

import java.util.Objects;

public class SalaryAccount {

	private long no;
	private String bankName,ifsc;
	public long getNo() {
		return no;
	}
	public void setNo(long no) {
		this.no = no;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public SalaryAccount(long no, String bankName, String ifsc) {
		super();
		this.no = no;
		this.bankName = bankName;
		this.ifsc = ifsc;
	}
	public SalaryAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		return Objects.hash(bankName, ifsc, no);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SalaryAccount other = (SalaryAccount) obj;
		return Objects.equals(bankName, other.bankName) && Objects.equals(ifsc, other.ifsc) && no == other.no;
	} 

	@Override
	public String toString() {
		return "SalaryAccount [no=" + no + ", bankName=" + bankName + ", ifsc=" + ifsc + "]";
	}
	
}
