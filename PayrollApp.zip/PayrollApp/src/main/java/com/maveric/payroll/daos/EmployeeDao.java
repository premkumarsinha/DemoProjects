package com.maveric.payroll.daos;

import java.util.Optional;

import com.maveric.payroll.entities.Employee;

public interface EmployeeDao {

	Employee save (Employee employee);
	Optional<Employee> remove(int no);
	Employee update(Employee employee);
	Optional<Employee> getEmployeeByNo(int no);
}
