package com.maveric.payroll.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

import com.maveric.payroll.entities.Employee;
import com.maveric.payroll.entities.SalaryAccount;
import com.maveric.payroll.utils.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	Connection con;
	SalaryAccountDao salaryAccountDao=new SalaryAccountDaoImpl();
	
	public EmployeeDaoImpl() {
		con=DBUtil.getConn();
		}

	@Override
	public Employee save(Employee employee) {
		try {
			con.setAutoCommit(false);
		PreparedStatement ps=con.prepareStatement("insert into employee(investment_under_80C,basic_pay,name,designation,pf_no,pancard_no,doj,dob) values(?,?,?,?,?,?,?,?)");
		ps.setDouble(1,employee.getInvestmentUnder80C());
		ps.setDouble(2, employee.getBasicPay());
		ps.setString(3, employee.getName());
		ps.setString(4, employee.getDesignation());
		ps.setString(5, employee.getPfNo());
		ps.setString(6, employee.getPancardNo());
		ps.setString(7, employee.getDOJ());
		ps.setString(8, employee.getDOB());
		int rowAffected=ps.executeUpdate();
		ps = con.prepareStatement("select max(employee_id) from employee");
		ResultSet resultSet = ps.executeQuery();  
		resultSet.next();
		int employeeNo = resultSet.getInt(1);
		employee.setId(employeeNo);
		ps = con.prepareStatement("insert into salary_account (account_no ,bank_name,ifsc_code,employee_id)values(?,?,?,?)");
		ps.setLong(1, employee.getSalaryAccount().getNo());
		ps.setString(2, employee.getSalaryAccount().getBankName());
		ps.setString(3, employee.getSalaryAccount().getIfsc());
		ps.setInt(4, employeeNo);
		ps.executeUpdate();
		System.out.println(rowAffected + "  row inserted ");
		con.commit();
		}catch(SQLException e)
		{
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		finally {
			try {
				con.setAutoCommit(true);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return employee;
	
	}

	@Override
	public Optional<Employee> remove(int no) {
		return null;
	}

	@Override
	public Employee update(Employee employee) {

		try {
			PreparedStatement ps=con.prepareStatement("update employee set investment_under_80C=?,basic_pay=?,name=?,designation=?,pf_no=?,pancard_no=?,doj=?,dob=? where employee_id=?");
			ps.setDouble(1, employee.getId());
			ps.setDouble(2, employee.getBasicPay());
			ps.setString(3,employee.getName());
			ps.setString(4,employee.getDesignation());
			ps.setString(5, employee.getPfNo());
			ps.setString(6, employee.getPancardNo());
			ps.setString(7, employee.getDOJ());
			ps.setString(8, employee.getDOB());
			ps.setInt(9, employee.getId());
			int rowsAffected=ps.executeUpdate();
			
			System.out.println(rowsAffected + "  row updated ");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employee;
	}

	@Override
	public Optional<Employee> getEmployeeByNo(int no) {
		try {
			ResultSet rset = con.prepareStatement("select * from employee where employee_id="+ no).executeQuery();
			if(rset.next()) {
				return Optional.of(new Employee(rset.getInt(1),rset.getDouble(2),rset.getDouble(3),rset.getString(4),rset.getString(5),rset.getString(6),rset.getString(7),rset.getString(8),rset.getString(9),null,salaryAccountDao.getSalaryAccount(no)));
			} else {
				Optional.empty();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Optional.ofNullable(null);
	}




}
