package com.maveric.payroll.services;

import com.maveric.payroll.entities.Employee;
import com.maveric.payroll.entities.Salary;
import com.maveric.payroll.entities.SalaryAccount;
import com.maveric.payroll.exception.EmployeeDetailsNotFoundException;
import com.maveric.payroll.exception.SalaryDetailsNotFoundException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import com.maveric.payroll.daos.EmployeeDao;
import com.maveric.payroll.daos.EmployeeDaoImpl;
import com.maveric.payroll.daos.SalaryDaoImpl;
import com.maveric.payroll.daos.SalaryDao;


public class PayrollServiceImpl implements PayrollService {
	
	private EmployeeDao employeeDao=new EmployeeDaoImpl();
	private SalaryDao salaryDao=new SalaryDaoImpl();
	

	public PayrollServiceImpl(EmployeeDao employeeDao,SalaryDao salaryDao) {
		this.employeeDao = employeeDao;
		this.salaryDao = salaryDao;
	}

	
	@Override
	public Employee getEmployeeDetails(int id) throws EmployeeDetailsNotFoundException {
		return employeeDao.getEmployeeByNo(id).orElseThrow(()->new EmployeeDetailsNotFoundException("Employee details not found for id :"+id));
	}

	@Override
	public Salary getEmployeeSalaryDetails(int id, String month) throws SalaryDetailsNotFoundException, EmployeeDetailsNotFoundException{
		getEmployeeDetails(id);
		return salaryDao.getSalaryDetails(id, month).orElseThrow(()->new SalaryDetailsNotFoundException("Salary Not Found"));
	}

	

	@Override
	public double calculateMonthNetSalary(int id,String month,int noOfLeaves) throws EmployeeDetailsNotFoundException {
		double dailyLeaveDeduction=200,annualGross=0,investment=0,taxAmount=0; 
		Employee emp=getEmployeeDetails(id);
		
		
		Salary sal=new Salary();
		sal.setNoOfLeaves(noOfLeaves);
		sal.setMonth(month);
		sal.setDa(0.3*emp.getBasicPay());
		sal.setHra(0.3*emp.getBasicPay());
		sal.setTa(0.3*emp.getBasicPay());
		sal.setPfAmt(0.12*emp.getBasicPay());
		if(emp.getInvestmentUnder80C()>150000)
			investment=150000;
		else
			investment=emp.getInvestmentUnder80C();
		annualGross=12*(emp.getBasicPay()+sal.getDa()+sal.getHra()+sal.getTa());
		if(annualGross<=250000)
			taxAmount=0;
		else if(annualGross<=500000)
			taxAmount=0.1*(annualGross-(250000+investment));
		else if(annualGross<=750000)
			taxAmount=0.1*(250000-investment)+0.15*(annualGross-500000);
		else if(annualGross<=1000000)
			taxAmount=0.1*(250000-investment)+0.15*(250000)+0.2*(annualGross-750000);
		else if(annualGross>1000000)
			taxAmount=0.1*(250000-investment)+0.15*(250000)+0.2*(250000)+0.3*(annualGross-1000000);
		sal.setMonthlyTax(taxAmount/12);
		sal.setNetSalary(((annualGross-taxAmount)/12)-(sal.getNoOfLeaves()*dailyLeaveDeduction+sal.getPfAmt()));
		salaryDao.addSalary(sal, id);
		return sal.getNetSalary();
	}

	@Override
	public Employee createEmployee(String name, String designation, String pfNo, String pancardNo, String dOJ,
			String dOB, double investmentUnder80C,double basicPay,SalaryAccount salaryAccount,ArrayList<Salary> salary) {
			Employee employee=new Employee(name,designation,pfNo,pancardNo,dOJ,dOB,investmentUnder80C,basicPay,salaryAccount,salary);
			return employeeDao.save(employee);
	}

}
