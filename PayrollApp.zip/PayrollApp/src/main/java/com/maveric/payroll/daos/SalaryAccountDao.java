package com.maveric.payroll.daos;

import com.maveric.payroll.entities.SalaryAccount;

public interface SalaryAccountDao {

	SalaryAccount getSalaryAccount(int id);

}
