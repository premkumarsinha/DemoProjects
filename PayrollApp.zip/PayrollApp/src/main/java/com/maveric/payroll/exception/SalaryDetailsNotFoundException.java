package com.maveric.payroll.exception;

public class SalaryDetailsNotFoundException extends Exception{

	public SalaryDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SalaryDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SalaryDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SalaryDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SalaryDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
