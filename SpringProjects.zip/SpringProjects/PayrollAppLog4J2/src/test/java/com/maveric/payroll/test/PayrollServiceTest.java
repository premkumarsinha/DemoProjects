package com.maveric.payroll.test;
import static org.mockito.Mockito.times;

import java.util.Optional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.maveric.payroll.daos.EmployeeDAO;
import com.maveric.payroll.entites.Employee;
import com.maveric.payroll.entites.Salary;
import com.maveric.payroll.entites.SalaryAccount;
import com.maveric.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.maveric.payroll.services.PayrollService;
import com.maveric.payroll.services.PayrollServiceImpl;


@ExtendWith(MockitoExtension.class)
public class PayrollServiceTest {
		
	private static PayrollService payrollService;

	private static EmployeeDAO  mockEmployeeDAO;
	
	@BeforeAll
	static void setUpTestEnv() {
		mockEmployeeDAO = Mockito.mock(EmployeeDAO.class);
		payrollService = new PayrollServiceImpl(mockEmployeeDAO);
	}
	
	@BeforeEach
	void setUpTestMockDataEnv() {
		Employee mockEmployee1 = new Employee(111, 100000, "Satish", "Mahajan", "26th", "6th", "Trainer", "IDJDJDKJ663K", "PF/100/JD23",
																							new Salary[] {new Salary(15000)},new SalaryAccount(123, "HDFC", "hdfc007"));
		Employee mockEmployee2 = new Employee(222, 100000, "Jay", "Mahajan", "13n", "6th", "Trainer", "KDKLEL763", "PF/100/ODJDK",
				new Salary[] {new Salary(35000)},new SalaryAccount(636, "HDFC", "hdfc007"));
		
		
		Employee mockEmployee3 = new Employee(100000, "Jay", "Mahajan", "13n", "6th", "Trainer", "KDKLEL763", "PF/100/ODJDK",
				new SalaryAccount(636, "HDFC", "hdfc007"));
		
		Mockito.when(mockEmployeeDAO.getEmployeeByNo(111)).thenReturn(Optional.of(mockEmployee1));
		Mockito.when(mockEmployeeDAO.getEmployeeByNo(222)).thenReturn(Optional.of(mockEmployee2));
		Mockito.when(mockEmployeeDAO.getEmployeeByNo(555)).thenReturn(Optional.ofNullable(null));
		Mockito.when(mockEmployeeDAO.getEmployeeByNo(777)).thenReturn(Optional.ofNullable(null));
		Mockito.when(mockEmployeeDAO.save(new Employee(100000, "Jay", "Mahajan", "13n", "6th", "Trainer", "KDKLEL763", "PF/100/ODJDK",
				new SalaryAccount(636, "HDFC", "hdfc007")))).thenReturn(new Employee(333,100000, "Jay", "Mahajan", "13n", "6th", "Trainer", "KDKLEL763", "PF/100/ODJDK",
						new SalaryAccount(636, "HDFC", "hdfc007")));
	}
	
	
	@Test
	@DisplayName (value = "TestGetEmployeeDetailsForInvalidEmployeeNo")
	void test1() {
		Assertions.assertThrows(EmployeeDetailsNotFoundException.class, ()->payrollService.getEmployeeDetails(777));
		Mockito.verify(mockEmployeeDAO ,times(1)).getEmployeeByNo(777);
	}
	
	
	@DisplayName (value = "TestGetEmployeeDetailsForValidEmployeeNo")
	void test2() throws EmployeeDetailsNotFoundException {
		
		Employee expectedEmployee = new Employee(111, 100000, "Satish", "Mahajan", "26th", "6th", "Trainer", "IDJDJDKJ663K", "PF/100/JD23",
				new Salary[] {new Salary(15000)},new SalaryAccount(123, "HDFC", "hdfc007"));
		
		Employee actualEmployee = payrollService.getEmployeeDetails(111);
		
		Assertions.assertEquals(expectedEmployee, actualEmployee);   //  ==  || equals()   ---->  
		
		Mockito.verify(mockEmployeeDAO ,times(1)).getEmployeeByNo(111);
		
	}
	
	
	@AfterAll
	public static void tearDownPayrollServices() {
		mockEmployeeDAO = null;
		payrollService = null;
	}

}
