package com.maveric.payroll.daos;
import java.util.Optional;
import com.maveric.payroll.entites.Employee;
public interface EmployeeDAO {
	
	Employee save (Employee employee);
	Optional<Employee>   remove(int no);
	Employee update(Employee employee);
	Optional<Employee> getEmployeeByNo(int no);

}
