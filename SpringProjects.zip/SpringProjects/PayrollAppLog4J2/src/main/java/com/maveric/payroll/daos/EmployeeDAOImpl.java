package com.maveric.payroll.daos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

import com.maveric.payroll.entites.Employee;
import com.maveric.payroll.utils.DBUtil;
public class EmployeeDAOImpl implements EmployeeDAO{
	private Connection conn ;
	public EmployeeDAOImpl() {
		conn = DBUtil.getDBConnection();
	}

	@Override
	public Employee save(Employee employee) {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt = conn.prepareStatement("insert into employee(firstName,lastName,dateOfJoining,dateOfBirth,designation,pancardNo,pfNo,investmentUnder80C)values(?,?,?,?,?,?,?,?) ");
			pstmt.setString(1, employee.getFirstName());
			pstmt.setString(2, employee.getLastName());
			pstmt.setString(3, employee.getDateOfJoining());
			pstmt.setString(4, employee.getDateOfBirth());
			pstmt.setString(5, employee.getDesignation());
			pstmt.setString(6, employee.getPancardNo());
			pstmt.setString(7, employee.getPfNo());
			pstmt.setInt(8, employee.getInvestmentUnder80C());
			int rowEffected= pstmt.executeUpdate();    //------ for DML operation
			
			
			//pstmt = conn.prepareStatement("select no  from employeee order by desc limit 1")
			
			pstmt = conn.prepareStatement("select max(no) from employee");
			
			ResultSet resultSet = pstmt.executeQuery();     // ---------> for DQL operations
			resultSet.next();
			int employeeNo = resultSet.getInt(1);
			employee.setNo(employeeNo);
			
			// insert SalaryAccount
			
			pstmt = conn.prepareStatement("insert into SalaryAccount (no,accountno ,bankname,ifscode)values(?,?,?,?)");
			pstmt.setInt(1, employeeNo);
			pstmt.setInt(2, employee.getSalaryAccount().getAccountNo());
			pstmt.setString(3, employee.getSalaryAccount().getBankName());
			pstmt.setString(4, employee.getSalaryAccount().getIfsCode());
			pstmt.executeUpdate();
			
			System.out.println(rowEffected + "  row inserted ");
			
			conn.commit();
			
		}catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
		finally {
			try {
				conn.setAutoCommit(true);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return employee;
	}

	@Override
	public Optional<Employee> remove(int no) {

		return Optional.empty();
	}

	@Override
	public Employee update(Employee employee) {
		return null;
	}

	@Override
	public Optional<Employee> getEmployeeByNo(int no) {
		
		try {
			ResultSet rs = conn.prepareStatement("select * from Employee where no = "+no).executeQuery();
			if(rs.next())
				return  Optional.of(new Employee(rs.getInt("no"),rs.getInt("investmentUnder80C"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("dateOfJoining"), rs.getString("dateOfBirth"), rs.getString("designation"), rs.getString("pancardNo"), rs.getString("pfNo")));
			else Optional.empty();	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Optional.empty();
	}


}
