package com.maveric.payroll.utils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;


public class DBUtil {

	
	//private static Logger logger = LogManager.getLogger(DBUtil.class);
	
	private static Logger logger = LoggerFactory.getLogger(DBUtil.class);
 
	private static Connection conn;

	static {
		try {
			Properties properties = new Properties();
			properties.load(new FileInputStream(new File("./Resources/payrolldb.properties")));
			Class.forName(properties.getProperty("driver"));
			conn = DriverManager.getConnection(properties.getProperty("url"), properties.getProperty("user"), properties.getProperty("password"));
		} catch (SQLException|IOException | ClassNotFoundException e) {
			logger.error(e.getMessage());
		}
	}

	public static Connection getDBConnection() {
		
		return conn;
	}
}
