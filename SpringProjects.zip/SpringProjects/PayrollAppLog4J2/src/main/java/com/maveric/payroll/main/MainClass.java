package com.maveric.payroll.main;
import com.maveric.payroll.entites.Employee;
import com.maveric.payroll.services.PayrollService;
import com.maveric.payroll.services.PayrollServiceImpl;
public class MainClass {
	public static void main(String[] args) {
		PayrollService payrollService = new PayrollServiceImpl();
		Employee employee = payrollService.createEmployee("Satish", "Mahajan", "26th", "6th", "Trainer", "KDKKD73", "PF/1000/JDJD", 100000, 111, "hdfc", "hdfc0007");
		System.out.println(employee);
	}
}