package com.maveric.payroll.services;

import com.maveric.payroll.entites.Employee;
import com.maveric.payroll.entites.Salary;
import com.maveric.payroll.exceptions.EmployeeDetailsNotFoundException;

public interface PayrollService {
	
	Employee createEmployee(String firstName,String lastName, String dateOfJoining,String dateOfBirth,String designation,String pancardNo,String pfNo, int investmentUnder80C , int accpountNo , String bankName,String ifsCode );

	Employee getEmployeeDetails(int no)throws EmployeeDetailsNotFoundException;
	
	Salary getEmployeeSalaryDetails(int no,String month)throws EmployeeDetailsNotFoundException;
	
	int calculateMonthNetSalary(int no,String month, int basicSalary,int noOfLeaveTakenInMonth)throws EmployeeDetailsNotFoundException;

}
