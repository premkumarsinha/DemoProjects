package com.maveric.payroll.services;

import com.maveric.payroll.daos.EmployeeDAO;
import com.maveric.payroll.daos.EmployeeDAOImpl;
import com.maveric.payroll.entites.Employee;
import com.maveric.payroll.entites.Salary;
import com.maveric.payroll.entites.SalaryAccount;
import com.maveric.payroll.exceptions.EmployeeDetailsNotFoundException;

public class PayrollServiceImpl implements PayrollService {
	
	
	private EmployeeDAO dao ;
	
	
	public PayrollServiceImpl() {
		dao = new EmployeeDAOImpl();
	}

	
	public PayrollServiceImpl(EmployeeDAO dao) {
		super();
		this.dao = dao;
	}


	@Override
	public Employee createEmployee(String firstName, String lastName, String dateOfJoining, String dateOfBirth,
			String designation, String pancardNo, String pfNo, int investmentUnder80C, int accpountNo, String bankName,
			String ifsCode) {
		return 	dao.save(new Employee(investmentUnder80C, firstName, lastName, dateOfJoining, dateOfBirth, designation, pancardNo, pfNo, new SalaryAccount(accpountNo, bankName, ifsCode)));
	}

	@Override
	public Employee getEmployeeDetails(int no) throws EmployeeDetailsNotFoundException {
		/*
		Optional<Employee> optional= dao.getEmployeeByNo(no);
		Supplier<EmployeeDetailsNotFoundException> supplier = ()-> new EmployeeDetailsNotFoundException("Employee Details not found for id "+no);
		return optional.orElseThrow(supplier);
		
		*/
		return dao.getEmployeeByNo(no).orElseThrow(()-> new EmployeeDetailsNotFoundException("Employee Details not found for id "+no));
		
		
	}

	@Override
	public Salary getEmployeeSalaryDetails(int no, String month) throws EmployeeDetailsNotFoundException {
		return null;
	}

	@Override
	public int calculateMonthNetSalary(int no, String month, int basicSalary, int noOfLeaveTakenInMonth)
			throws EmployeeDetailsNotFoundException {
		return 0;
	}

	
}
