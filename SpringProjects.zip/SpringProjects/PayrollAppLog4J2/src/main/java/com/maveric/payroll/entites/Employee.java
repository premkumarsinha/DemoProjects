package com.maveric.payroll.entites;

import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Objects;

public class Employee {
	
	private  int no, investmentUnder80C;
	private String firstName,lastName, dateOfJoining,dateOfBirth,designation,pancardNo,pfNo;
	
	private DateTimeFormatter date;
	private Salary [] salaries;
	
	private SalaryAccount salaryAccount;

	public Employee() {}

	
	
	public Employee(int investmentUnder80C, String firstName, String lastName, String dateOfJoining, String dateOfBirth,
			String designation, String pancardNo, String pfNo, SalaryAccount salaryAccount) {
		super();
		this.investmentUnder80C = investmentUnder80C;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfJoining = dateOfJoining;
		this.dateOfBirth = dateOfBirth;
		this.designation = designation;
		this.pancardNo = pancardNo;
		this.pfNo = pfNo;
		this.salaryAccount = salaryAccount;
	}
	
	
	

	

	public Employee(int no, int investmentUnder80C, String firstName, String lastName, String dateOfJoining,
			String dateOfBirth, String designation, String pancardNo, String pfNo, SalaryAccount salaryAccount) {
		super();
		this.no = no;
		this.investmentUnder80C = investmentUnder80C;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfJoining = dateOfJoining;
		this.dateOfBirth = dateOfBirth;
		this.designation = designation;
		this.pancardNo = pancardNo;
		this.pfNo = pfNo;
		this.salaryAccount = salaryAccount;
	}



	public Employee(int no, int investmentUnder80C, String firstName, String lastName, String dateOfJoining,
			String dateOfBirth, String designation, String pancardNo, String pfNo) {
		super();
		this.no = no;
		this.investmentUnder80C = investmentUnder80C;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfJoining = dateOfJoining;
		this.dateOfBirth = dateOfBirth;
		this.designation = designation;
		this.pancardNo = pancardNo;
		this.pfNo = pfNo;
	}



	public Employee(int no, int investmentUnder80C, String firstName, String lastName, String dateOfJoining,
			String dateOfBirth, String designation, String pancardNo, String pfNo, Salary[] salaries,
			SalaryAccount salaryAccount) {
		super();
		this.no = no;
		this.investmentUnder80C = investmentUnder80C;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfJoining = dateOfJoining;
		this.dateOfBirth = dateOfBirth;
		this.designation = designation;
		this.pancardNo = pancardNo;
		this.pfNo = pfNo;
		this.salaries = salaries;
		this.salaryAccount = salaryAccount;
	}



	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public int getInvestmentUnder80C() {
		return investmentUnder80C;
	}

	public void setInvestmentUnder80C(int investmentUnder80C) {
		this.investmentUnder80C = investmentUnder80C;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getPancardNo() {
		return pancardNo;
	}

	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}

	public String getPfNo() {
		return pfNo;
	}

	public void setPfNo(String pfNo) {
		this.pfNo = pfNo;
	}

	public Salary[] getSalaries() {
		return salaries;
	}

	public void setSalaries(Salary[] salaries) {
		this.salaries = salaries;
	}

	public SalaryAccount getSalaryAccount() {
		return salaryAccount;
	}

	public void setSalaryAccount(SalaryAccount salaryAccount) {
		this.salaryAccount = salaryAccount;
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(salaries);
		result = prime * result + Objects.hash(dateOfBirth, dateOfJoining, designation, firstName, investmentUnder80C,
				lastName, no, pancardNo, pfNo, salaryAccount);
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(dateOfBirth, other.dateOfBirth) && Objects.equals(dateOfJoining, other.dateOfJoining)
				&& Objects.equals(designation, other.designation) && Objects.equals(firstName, other.firstName)
				&& investmentUnder80C == other.investmentUnder80C && Objects.equals(lastName, other.lastName)
				&& no == other.no && Objects.equals(pancardNo, other.pancardNo) && Objects.equals(pfNo, other.pfNo)
				&& Arrays.equals(salaries, other.salaries) && Objects.equals(salaryAccount, other.salaryAccount);
	}



	@Override
	public String toString() {
		return "Employee [no=" + no + ", investmentUnder80C=" + investmentUnder80C + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dateOfJoining=" + dateOfJoining + ", dateOfBirth=" + dateOfBirth
				+ ", designation=" + designation + ", pancardNo=" + pancardNo + ", pfNo=" + pfNo + ", salaries="
				+ Arrays.toString(salaries) + ", salaryAccount=" + salaryAccount + "]";
	}
}