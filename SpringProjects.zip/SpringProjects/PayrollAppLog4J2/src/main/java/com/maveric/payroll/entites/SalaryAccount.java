package com.maveric.payroll.entites;

import java.util.Objects;

public class SalaryAccount {
	
	private	int accountNo;
	private String bankName,ifsCode;
	
	public SalaryAccount() {
		// TODO Auto-generated constructor stub
	}
	public SalaryAccount(int accountNo, String bankName, String ifsCode) {
		super();
		this.accountNo = accountNo;
		this.bankName = bankName;
		this.ifsCode = ifsCode;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getIfsCode() {
		return ifsCode;
	}
	public void setIfsCode(String ifsCode) {
		this.ifsCode = ifsCode;
	}
	
	
	
	@Override
	public int hashCode() {
		return Objects.hash(accountNo, bankName, ifsCode);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SalaryAccount other = (SalaryAccount) obj;
		return accountNo == other.accountNo && Objects.equals(bankName, other.bankName)
				&& Objects.equals(ifsCode, other.ifsCode);
	}
	@Override
	public String toString() {
		return "SalaryAccount [accountNo=" + accountNo + ", bankName=" + bankName + ", ifsCode=" + ifsCode + "]";
	}

	

}
