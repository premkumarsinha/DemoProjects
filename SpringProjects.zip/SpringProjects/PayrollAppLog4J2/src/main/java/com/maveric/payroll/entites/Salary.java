package com.maveric.payroll.entites;

import java.util.Objects;

public class Salary {
	private int basicSalary,hra,ta,da,otherAllowance,monthlyTax,netSalary,noOfLeaveTakenInMonth;
	private String month ;
	public Salary(int basicSalary) {
		super();
		this.basicSalary = basicSalary;
	}

	public Salary(int basicSalary, int hra, int ta, int da, int otherAllowance, int monthlyTax, int netSalary,
			int noOfLeaveTakenInMonth, String month) {
		super();
		this.basicSalary = basicSalary;
		this.hra = hra;
		this.ta = ta;
		this.da = da;
		this.otherAllowance = otherAllowance;
		this.monthlyTax = monthlyTax;
		this.netSalary = netSalary;
		this.noOfLeaveTakenInMonth = noOfLeaveTakenInMonth;
		this.month = month;
	}

	@Override
	public int hashCode() {
		return Objects.hash(basicSalary, da, hra, month, monthlyTax, netSalary, noOfLeaveTakenInMonth, otherAllowance,
				ta);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Salary other = (Salary) obj;
		return basicSalary == other.basicSalary && da == other.da && hra == other.hra
				&& Objects.equals(month, other.month) && monthlyTax == other.monthlyTax && netSalary == other.netSalary
				&& noOfLeaveTakenInMonth == other.noOfLeaveTakenInMonth && otherAllowance == other.otherAllowance
				&& ta == other.ta;
	}

	public int getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}

	public int getOtherAllowance() {
		return otherAllowance;
	}

	public void setOtherAllowance(int otherAllowance) {
		this.otherAllowance = otherAllowance;
	}

	public int getMonthlyTax() {
		return monthlyTax;
	}

	public void setMonthlyTax(int monthlyTax) {
		this.monthlyTax = monthlyTax;
	}

	public int getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(int netSalary) {
		this.netSalary = netSalary;
	}

	public int getNoOfLeaveTakenInMonth() {
		return noOfLeaveTakenInMonth;
	}

	public void setNoOfLeaveTakenInMonth(int noOfLeaveTakenInMonth) {
		this.noOfLeaveTakenInMonth = noOfLeaveTakenInMonth;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

}
