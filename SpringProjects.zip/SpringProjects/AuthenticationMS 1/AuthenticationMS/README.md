# AuthenticationMS
Microservice for providing role specific access, preventing unauthorized activities
