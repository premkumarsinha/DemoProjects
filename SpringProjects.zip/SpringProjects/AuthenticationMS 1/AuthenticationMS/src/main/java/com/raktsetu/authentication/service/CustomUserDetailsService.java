package com.raktsetu.authentication.service;

import com.raktsetu.authentication.entity.Account;
import com.raktsetu.authentication.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    AccountRepository accountRepository;

    @Override
    public UserDetails loadUserByUsername(String emailId) throws UsernameNotFoundException {
        Account account = accountRepository.findById(emailId).orElseThrow(()->
            new UsernameNotFoundException("Account not found : "+ emailId)
        );
        return new User(account.getEmailId(), account.getPassword(),account.getIsActive(),true, true,true, List.of(new SimpleGrantedAuthority("ROLE_" + account.getAccountRole().name())));
    }
}
