package com.raktsetu.authentication.controller;

import com.raktsetu.authentication.dto.AuthRequest;
import com.raktsetu.authentication.dto.AuthResponse;
import com.raktsetu.authentication.entity.Account;
import com.raktsetu.authentication.repository.AccountRepository;
import com.raktsetu.authentication.service.AccountServiceImpl;
import com.raktsetu.authentication.service.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/authenticate")
public class AccountController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    public AccountServiceImpl accountService;

    @PostMapping("/register")
    public ResponseEntity<Account> registerAccount(@RequestBody Account account){
        return ResponseEntity.ok(accountService.registerAccount(account));
    }

    @GetMapping("/welcome")
    public ResponseEntity<String> welcome(){
        System.out.println("Welcome to raktsetu");
        return ResponseEntity.ok("Hi Welcome to the Raktsetu app.");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest authRequest){
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(authRequest.getEmailId(),authRequest.getPassword())
        );
        String token = jwtService.generateToken((UserDetails) authentication.getPrincipal());
        System.out.println("Logout");
        return ResponseEntity.ok(new AuthResponse(token));
    }
}
