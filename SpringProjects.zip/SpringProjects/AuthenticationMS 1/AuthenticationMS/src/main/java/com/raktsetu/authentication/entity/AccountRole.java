package com.raktsetu.authentication.entity;

public enum AccountRole {
    USER, HOSPITAL, BLOODBANK
}
