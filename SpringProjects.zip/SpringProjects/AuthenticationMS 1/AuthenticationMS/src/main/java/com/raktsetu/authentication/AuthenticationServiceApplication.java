package com.raktsetu.authentication;

import com.raktsetu.authentication.entity.Account;
import com.raktsetu.authentication.entity.AccountRole;
import com.raktsetu.authentication.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDateTime;

@SpringBootApplication
public class AuthenticationServiceApplication  {

	@Autowired
	private AccountRepository accountRepository;

	public static void main(String[] args) {

		SpringApplication.run(AuthenticationServiceApplication.class, args);
	}


}
