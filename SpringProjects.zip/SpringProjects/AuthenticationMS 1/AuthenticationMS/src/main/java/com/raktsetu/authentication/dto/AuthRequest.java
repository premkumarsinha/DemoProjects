package com.raktsetu.authentication.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class AuthRequest {

    private String emailId;
    private String password;
}


