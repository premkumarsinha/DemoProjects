package com.raktsetu.authentication.service;

import com.raktsetu.authentication.entity.Account;
import com.raktsetu.authentication.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    public AccountRepository accountRepository;

    @Autowired
    public BCryptPasswordEncoder passwordEncoder;

    @Override
    public Account registerAccount(Account account) {
        account.setPassword(passwordEncoder.encode(account.getPassword())); // Hash the password
        account.setIsActive(true);
        account.setCreatedOn(LocalDateTime.now());
        account.setUpdatedOn(account.getCreatedOn());
        return accountRepository.save(account);
    }
}
