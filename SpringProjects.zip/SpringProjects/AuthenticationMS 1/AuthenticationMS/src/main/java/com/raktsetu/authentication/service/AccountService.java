package com.raktsetu.authentication.service;

import com.raktsetu.authentication.entity.Account;

public interface AccountService {
    public Account registerAccount(Account account);
}
