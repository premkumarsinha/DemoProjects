package com.raktsetu.authentication.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "account")
public class Account {

    @Id
    @Column(name = "email_id")
    private String emailId;

    @Column(name = "password",nullable = false,length = 255)
    private String password;

    @Column(name = "is_active",nullable = false)
    private Boolean isActive;

    @Column(name = "account_role",nullable = false)
    @Enumerated(EnumType.STRING)
    private AccountRole accountRole;

    @Column(name = "created_on",nullable = false)
    private LocalDateTime createdOn;

    @Column(name = "updated_on",nullable = false)
    private LocalDateTime updatedOn;
}
