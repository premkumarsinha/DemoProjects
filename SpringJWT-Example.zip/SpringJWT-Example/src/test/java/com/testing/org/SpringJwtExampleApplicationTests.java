package com.testing.org;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJwtExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
