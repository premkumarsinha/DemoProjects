package com.testing.org.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/home")
@CrossOrigin
public class HomeController {

	@RequestMapping("users")
	public String welcome()
	{
		return "Hello this is your welcome";
	}
}
