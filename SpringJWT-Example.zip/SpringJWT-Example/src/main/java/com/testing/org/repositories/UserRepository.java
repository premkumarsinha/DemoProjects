package com.testing.org.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.testing.org.entity.User;

public interface UserRepository extends JpaRepository<User, String> {

}
