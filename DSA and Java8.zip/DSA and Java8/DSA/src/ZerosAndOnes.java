
public class ZerosAndOnes {

    public static void arrange(int[] arr){
        int i=0,j=0,temp;

        for(;i<arr.length;i++){

            if(arr[i]!=0&&arr[j]==0){
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }

            if(arr[j]!=0)
                j++;
        }
    }

    public static void main(String[] args) {
        int[] arr={0,1,0,0,1,1,0,1,0,1};
        arrange(arr);
        for(int num:arr)
            System.out.print(num+" ");
    }
}
