public class SecondMax {

    public static void main(String[] args) {
        int[] arr={23,11,9,45,15,97,33,2,8,101};

        int max=Integer.MIN_VALUE;
        int secondMax=Integer.MIN_VALUE;

        for(int num:arr){
            if(num>max){
                secondMax=max;
                max=num;
            }
            else if(num>secondMax&&num!=max)
                secondMax=num;

        }
        System.out.println("The second largest value in the given array is :"+secondMax);
    }
}
