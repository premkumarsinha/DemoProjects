import java.util.Stack;

public class ReverseStringUsingStack {

    public static String reverse(String text){
        Stack<Character> stack=new Stack<>();
        for(Character c:text.toCharArray())
            stack.push(c);
        StringBuilder result=new StringBuilder();
        while(!stack.isEmpty())
            result.append(stack.pop());

        return result.toString();
    }

    public static void main(String[] args) {
        String text="geeksforgeeks";
        System.out.println(reverse(text));
    }
}
