import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//Merge two unsorted arrays into sorted array without duplicates [2,4,5,6,3], [2,4,5,6,3,6,7,8,2]
public class Test{

    public static void main(String[] args) {

//        Integer[] arr1={2,4,5,6,3};
//        Integer[] arr2={2,4,5,6,3,6,7,8,2};
//
////        Stream.concat(Arrays.stream(arr1),Arrays.stream(arr2)).distinct().sorted((a,b)->a-b)
////                .forEach(System.out::println);
//
//        List<Integer> list=new ArrayList<>(Arrays.asList(arr1));
//        list.addAll(new ArrayList<>(Arrays.asList(arr2)));
//        list.stream().distinct().sorted((a,b)-> a-b).forEach(System.out::println);

        System.out.println();

    }
}
