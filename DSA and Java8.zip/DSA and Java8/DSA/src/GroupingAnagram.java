import java.util.*;

public class GroupingAnagram {

    static List<List<String>> grouping(String arr[]){
        Map<String,List<String>> groups=new HashMap<>();

        for(String element:arr){
            char[] str=element.toCharArray();
            Arrays.sort(str);
            String sortedString=new String(str);
            if(!groups.containsKey(sortedString))
                groups.put(sortedString,new ArrayList<>());

            groups.get(sortedString).add(element);
        }

        return new ArrayList<>(groups.values());
    }

    public static void main(String[] args) {
        String[] arr={"eat","tea","tan","ate","nat","bat"};
        System.out.println(grouping(arr));
    }
}
