
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Stack;

public class NonRepeatingChar {

    public static void main(String[] args) {
        String text="racedcarf";
        Map<Character,Integer> count=new HashMap<>();
        char val='$';
        for(char c:text.toCharArray()){
            if(!count.containsKey(c))
                count.put(c,1);
            else
                count.put(c,count.get(c)+1);
//            System.out.println("Key="+c+" value="+count.get(c));
        }
        System.out.println(count);
        for(char c:count.keySet()){
            if(count.get(c)==1){
                val=c;
                break;
            }
        }
        System.out.println(val);

    }
}
