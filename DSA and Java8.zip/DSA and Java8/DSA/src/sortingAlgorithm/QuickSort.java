package sortingAlgorithm;

public class QuickSort {

    public static int partition(int[] arr,int low,int high){
        int pivot=high;
        int i=low;
        int j=low;
        while(i<=high){
            if(arr[i]<=arr[pivot]){
                int temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }

            if(arr[j]<arr[pivot])
                j++;
            i++;
        }
        return j-1;
    }
    public static void sort(int[] arr,int low,int high){
        if(low<high){
            int partition=partition(arr,low,high);
            sort(arr,low,partition-1);
            sort(arr,partition+1,high);
        }
    }

    public static void main(String[] args) {
        int[] arr={23,11,9,45,15,97,33,2,8};
        sort(arr,0,arr.length-1);
        for(int i:arr)
            System.out.print(i+" ");
    }
}
