package sortingAlgorithm;

public class InsertionSort {

    public static void sort(int[] arr){

        for(int i=1;i<arr.length;i++){

            for(int j=i;j>0;j--)
                if(arr[j]>arr[j-1])
                    break;
                else{
                    int temp=arr[j];
                    arr[j]=arr[j-1];
                    arr[j-1]=temp;
                }
            System.out.print("After iteration "+i+" :");
            for(int num:arr)
                System.out.print(num+" ");
            System.out.println();
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] arr={23,11,9,45,15,97,33,2,8};
        sort(arr);
        for(int i:arr)
            System.out.print(i+" ");

    }
}
