package sortingAlgorithm;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Stock {

    public static int buyStock(int[] arr){
        int stockPrice=0,i=0,j=1;

        while(i<arr.length-1){
            System.out.println("i="+i+" j="+j);
            if(j>arr.length-1){
                i=i+1;
                j=i+1;
            }
            if(arr[j]-arr[i]>stockPrice)
                stockPrice=arr[j]-arr[i];
            j++;
        }
        return stockPrice;
    }

    public static void main(String[] args) {
//        int[] arr={7,6,4,3,1};
//        System.out.println("The price of the stock is : "+buyStock(arr));

//        List<String> fruits= Arrays.asList("Mango","Strawberry","Apple","Guava");
//
//        fruits.stream().sorted(Comparator.naturalOrder()).toList().forEach(System.out::println);

        Stream.of(4,5,6,1,2,2,5).reduce(Integer::sum).ifPresent(System.out::println);

    }
}
