import java.util.*;

public class CommonElement {

    public static void main(String[] args) {
        int[] arr1={1,2,2,1};
        int[] arr2={2,2};

        Set<Integer> result=new HashSet<>();
        List<Integer> secondArray= new ArrayList<>();

        for(int num:arr2)
            secondArray.add(num);

        for(int num:arr1) {
           if(secondArray.contains(num))
               result.add(num);
        }
        int[] intersection=result.stream().mapToInt(Integer::intValue).toArray();
        System.out.println(result);
    }
}
