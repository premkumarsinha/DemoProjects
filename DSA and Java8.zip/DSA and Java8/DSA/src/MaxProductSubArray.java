import java.util.Arrays;

public class MaxProductSubArray {

    public static int findMaxSum(int[] arr){
        int i=0,j=1,max=0;
        int[] temp;
        while(i<arr.length-1){
            if(j>arr.length-1){
                i=i+1;
                j=i+1;
            }
            temp= Arrays.copyOfRange(arr, i, j+1);
            Arrays.sort(temp);
            if(temp[0]+temp[1]>max)
                max=temp[0]+temp[1];
            j++;
        }
        return max;
    }

    public static void main(String[] args) {
        int[] arr={4, 3, 1, 5, 6};
        System.out.println("Max subarray sum is :"+findMaxSum(arr));
    }
}
