
public class RotateByOne {

    public static void rotateByOne(int[] arr){
        int temp=arr[arr.length-1];
        int takeOver;
        for(int i=0;i< arr.length;i++){
            takeOver=arr[i];
            arr[i]=temp;
            temp=takeOver;
        }
    }
    public static void main(String[] args) {
        int[] arr={1,2,3,4,5,6};
        rotateByOne(arr);
        for(int i:arr){
            System.out.print(i+" ");
        }
    }
}
