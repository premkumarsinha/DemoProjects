public class ConsecutiveZeros {

    public static void main(String[] args) {
        int[] arr={1,1,1,1,1,0,0,1,1,1,1,0,1,1,};
        int maxCount=0;
        int currentCount=0;
        for(int num:arr){
            currentCount=num==1?currentCount+1:0;
            if(currentCount>maxCount)
                maxCount=currentCount;
        }
        System.out.println("Maximum consecutive 1 count is "+maxCount);
    }
}
