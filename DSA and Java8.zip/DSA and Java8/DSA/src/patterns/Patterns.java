package patterns;

public class Patterns {

    public static void createPattern1(int n){

        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++)
                System.out.print("*");
            System.out.println();
        }
    }

    public static void createPattern2(int n){

        for(int i=0;i<n;i++){
            for(int j=0;j<=i;j++)
                System.out.print("*");
            System.out.println();
        }
    }

    public static void createPattern3(int n){

        for(int i=0;i<n;i++){
            for(int j=0;j<=i;j++)
                System.out.print(j+1);
            System.out.println();
        }
    }

    public static void createPattern4(int n){

        for(int i=0;i<n;i++){
            for(int j=0;j<=i;j++)
                System.out.print(i+1);
            System.out.println();
        }
    }

    public static void createPattern5(int n){

        for(int i=0;i<n;i++){
            for(int j=n;j>i;j--)
                System.out.print("*");
            System.out.println();
        }
    }

    public static void createPattern6(int n){
        for(int i=0;i<n;i++){
            for(int j=0;j<n-i;j++)
                System.out.print(j+1);
            System.out.println();
        }
    }

    public static void createPattern7(int n){
        for(int i=0;i<n;i++){
            for(int j=0;j<n-i-1;j++)
                System.out.print(" ");
            for(int k=0;k<=i;k++)
                System.out.print("*"+ " ");
            System.out.println();
        }

    }

    public static void createPattern8(int n){
        for(int i=0;i<n;i++){
            for(int j=0;j<i;j++)
                System.out.print(" ");
            for(int k=0;k<n-i;k++)
                System.out.print("*"+ " ");
            System.out.println();
        }

    }

    public static void createPattern9(int n){
        for(int i=0;i<n;i++){
            for(int j=0;j<n-i-1;j++)
                System.out.print(" ");
            for(int k=0;k<=i;k++)
                System.out.print("*"+ " ");
            System.out.println();
        }
        for(int i=0;i<n;i++){
            for(int j=0;j<i;j++)
                System.out.print(" ");
            for(int k=0;k<n-i;k++)
                System.out.print("*"+ " ");
            System.out.println();
        }

    }

    public static void createPattern10(int n){
        for(int i=0;i<n;i++) {
            for (int j = 0; j <= i; j++)
                if ((i + j) % 2 == 0)
                    System.out.print("1" + " ");
                else
                    System.out.print("0" + " ");
            System.out.println();
        }
    }

    public static void createPattern11(int n){

        for(int i=0;i<n;i++)
        {
            for(int j=0;j<=i;j++)
                System.out.print(j+1);
            for(int p=0;p<n-i-1;p++)
                System.out.print(" ");
            for(int q=0;q<n-i-1;q++)
                System.out.print(" ");
            for(int k=i+1;k>0;k--)
                System.out.print(k);
            System.out.println();
        }
    }

    public static void createPattern12(int n){
        for(int i=0;i<n;i++) {
            for(int j=0;j<n;j++){
                if(i==0||i==n-1)
                    System.out.print("*");
                else{
                    if(j==0||j==n-1)
                        System.out.print("*");
                    else
                        System.out.print(" ");
                }
            }
            System.out.println();
        }
    }

    public static void createPattern13(int n){
        int num=1;

        for(int i=0;i<n;i++){
            for(int j=0;j<=i;j++)
                System.out.print((num++)+" ");
            System.out.println();
        }
    }

    public static void createPattern14(int n){
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<=i;j++)
                System.out.print((char)(i+65));
            System.out.println();
        }
    }

    public static void createPattern15(int n){
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<=i;j++)
                System.out.print((char)(j+65));
            System.out.println();
        }
    }

    public static void createPattern16(int n){
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n-i;j++)
                System.out.print((char)(j+65));
            System.out.println();
        }
    }

    public static void createPattern17(int n){
        for(int i=0;i<2*n-1;i++)
        {
            for(int j=0;j<2*n-1;j++)
                System.out.print(n);
            System.out.println();
        }
    }

    public static void main(String[] args) {
//        createPattern1(5);
//        createPattern2(5);
//        createPattern3(5);
//        createPattern4(5);
//        createPattern5(5);
//        createPattern6(5);
//        createPattern7(5);
//        createPattern8(5);
//        createPattern9(5);
//        createPattern10(5);
//        createPattern11(4);
//        createPattern12(6);
//        createPattern13(5);
//        createPattern14(5);
//        createPattern15(5);
        createPattern16(7);

    }
}