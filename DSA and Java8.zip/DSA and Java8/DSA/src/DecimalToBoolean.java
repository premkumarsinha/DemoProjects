public class DecimalToBoolean {

    public static int covertToBinary(int num){
        StringBuilder result=new StringBuilder();
        while(num>0){
            result.append(num%2);
            num=num/2;
        }
        return Integer.parseInt(result.reverse().toString());
    }

    public static void main(String[] args) {

        int number=15;
        System.out.println(covertToBinary(number));
    }
}
