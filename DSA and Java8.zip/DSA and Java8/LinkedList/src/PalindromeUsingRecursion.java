public class PalindromeUsingRecursion {

    public boolean palindrome(String text){
        if(text.length()<2)
            return true;
        if(text.toLowerCase().charAt(0)==text.toLowerCase().charAt(text.length()-1)){
            boolean result=palindrome(text.substring(1,text.length()-1));
            return result;
        }
        else return false;
//        return true;
    }

    public  static void main(String[] args){

        String text="doobcood";
        PalindromeUsingRecursion obj=new PalindromeUsingRecursion();
        boolean isPalindrome=obj.palindrome(text);
        System.out.println(isPalindrome);

    }
}
