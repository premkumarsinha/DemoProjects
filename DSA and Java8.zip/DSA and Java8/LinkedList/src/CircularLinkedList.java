public class CircularLinkedList {

    private ListNode last;
    private int length;

    private class ListNode{
        private int data;
        private ListNode next;

        ListNode(int data){
            this.data=data;
        }
    }

    public void display() throws Exception {
        ListNode temp=last.next;
        if(last==null)
            throw new Exception("List is empty");
        while(temp!=last){
            System.out.print(temp.data+" -->");
            temp=temp.next;
        }
        System.out.print(last.data);
    }

    public void addNodeAtLast(int value){
        ListNode newNode=new ListNode(value);
        if(last==null){
            last=newNode;
            newNode.next=newNode;
        }
        else{
            newNode.next=last.next;
            last.next=newNode;
            last=newNode;
        }

        length++;
    }

    public void addNodeAtFirst(int value){
        ListNode newNode=new ListNode(value);
        if(last==null){
            last=newNode;
            newNode.next=newNode;
        }
        else{
            newNode.next=last.next;
            last.next=newNode;
        }
    }

    public int deleteNodeAtLast(){
        int value=-1;

        if(last==null)
            return value;
        else if(last.next==last){
                value=last.data;
                last=null;
                return value;
        }else{
            ListNode temp=last.next;
            while(temp.next!=last)
                temp=temp.next;
            temp.next=last.next;
            value=last.data;
            last=temp;
        }
        return value;
    }

    public int deleteNodeAtFirst(){
        int value=1;
        if(last==null)
            return value;
        else if(last==last.next){
            value=last.data;
            last=null;
        }
        else{
            value=last.next.data;
            last.next=last.next.next;
        }
        return value;
    }

    public static void main(String[] args) throws Exception {
        CircularLinkedList circularLinkedList=new CircularLinkedList();

        circularLinkedList.addNodeAtLast(10);
        circularLinkedList.addNodeAtLast(20);
        circularLinkedList.addNodeAtLast(30);
        circularLinkedList.addNodeAtFirst(40);
        circularLinkedList.addNodeAtFirst(50);
        System.out.println(circularLinkedList.last.next.data+" "+circularLinkedList.last.data);
        circularLinkedList.display();
        System.out.println("Deleted item: "+circularLinkedList.deleteNodeAtFirst());
        System.out.println(circularLinkedList.last.next.data+" "+circularLinkedList.last.data);
        circularLinkedList.display();
    }
}
