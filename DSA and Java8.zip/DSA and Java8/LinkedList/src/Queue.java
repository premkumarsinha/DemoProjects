import java.util.List;

public class Queue {

    private ListNode front;
    private ListNode rear;
    private int length;
    private class ListNode{
        private int data;
        private ListNode next;

        public ListNode(int data) {
            this.data = data;
        }
    }

    public void display() throws Exception {
        if(front==null)
            throw new Exception("Queue is empty");
        else{
            ListNode temp=front;
            while(temp!=null){
                System.out.print(temp.data+" -->");
                temp=temp.next;
            }
        }
        System.out.println("null");
    }

    public void enqueue(int value){
        ListNode newNode=new ListNode(value);
        if(front==null){
            front=newNode;
            rear=newNode;
        }
        else{
            rear.next=newNode;
            rear=newNode;
        }
        length++;
    }

    public void dequeue() throws Exception {
        if(front==null)
            throw new Exception("Queue is empty");
        else if(front==rear){
            front=rear=null;
        }
        else
            front=front.next;

        length--;
    }

    public int getLength(){
        return length;
    }

    public  static void main(String[] args) throws Exception {
        Queue queue=new Queue();
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        queue.display();
//        queue.dequeue();
//        queue.display();
        System.out.println("The length of the queue is :"+queue.getLength());
    }
}
