

class ListNode {
    public int value;
    public ListNode next;

    ListNode(int num) {
        value = num;
    }
}

public class Main {

    public static void addNode(int value, ListNode head) {
        ListNode node = new ListNode(value);
        if (head == null)
            head = node;
        else {
            ListNode current = head;
            while (current.next != null)
                current = current.next;
            current.next = node;
        }
//        return head;
    }

    public static void display(ListNode head) {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.value + " -->");
            current = current.next;
        }
        System.out.println("null");

    }

    public static ListNode deleteBeginningNode(ListNode head) throws Exception {
        if (head == null)
            throw new Exception("Linked list is empty");
        else
            head = head.next;
        return head;
    }

    public static ListNode addAtBeginning(ListNode head, int value) {
        ListNode node = new ListNode(value);
        if (head == null)
            head = node;
        else {
            ListNode currentNode = head;
            head = node;
            node.next = currentNode;
        }
        return head;
    }

    public static ListNode deleteAtNthPosition(ListNode head, int position) throws Exception {
        int counter = 1;
        ListNode temp = head;
        if (position < 1 || position > size(head))
            throw new Exception("Invalid position given");
        else if (position == 1)
            head = head.next;
        else {
            while (counter < position - 1) {
                temp = temp.next;
                counter++;
            }
            temp.next = temp.next.next;
        }
        return head;
    }

    public static ListNode addAtNthPosition(ListNode head,int position,int value) throws Exception {
        ListNode newNode=new ListNode(value);
        ListNode temp=head;
        int counter=1;
        if(position<1||position>size(head))
            throw new Exception("Not a valid position value");
        else if(position==1){
            newNode.next=head;
            head=newNode;
        }
        else {
            while(counter<position-1){
                counter++;
                temp=temp.next;
            }
            newNode.next=temp.next;
            temp.next=newNode;
        }
        return head;
    }

    public static int size(ListNode head) {
        int count = 0;
        while (head != null) {
            count++;
            head = head.next;
        }
        return count;
    }

    public static ListNode reverseList(ListNode head){
        ListNode previous=null;
        ListNode next=head.next;
        while(head.next!=null){
            head.next=previous;
            previous=head;
            head=next;
            next=next.next;
        }
        head.next=previous;
        return head;
    }

    public static void main(String[] args) throws Exception {
        ListNode head = null;
//        addNodeAtLast(10,head);
//        display(head);
//        head = addAtBeginning(head, 20);
        addNode(30,head);
//        head = addAtBeginning(head, 30);
//        head = addAtBeginning(head, 40);
//        head = addAtBeginning(head, 50);
//        head = addAtBeginning(head, 60);
        display(head);
//        head=deleteBeginningNode(head);
//        display(head);
//        System.out.println(size(head));
//        head = deleteAtNthPosition(head, 3);
//        display(head);
//        System.out.println(size(head));
//        head=addAtNthPosition(head,4,60);
//        display(head);
//        head=reverseList(head);
//        display(head);
    }
}