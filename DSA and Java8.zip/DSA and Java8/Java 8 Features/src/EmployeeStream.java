import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

class EmployeeP{
    int id;
    String name;
    String department;
    double salary;
    int age;
    boolean isActive;

    public EmployeeP(int id, String name, String department, double salary, int age, boolean isActive) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
        this.age = age;
        this.isActive = isActive;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Override
    public String toString() {
        return "EmployeeP{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", department='" + department + '\'' +
                ", salary=" + salary +
                ", age=" + age +
                ", isActive=" + isActive +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmployeeP employeeP = (EmployeeP) o;
        return id == employeeP.id && Double.compare(salary, employeeP.salary) == 0 && age == employeeP.age && isActive == employeeP.isActive && Objects.equals(name, employeeP.name) && Objects.equals(department, employeeP.department);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, department, salary, age, isActive);
    }
}

public class EmployeeStream {

    public static void main(String[] args) {

        List<EmployeeP> employees = Arrays.asList(
                new EmployeeP(1, "Alice", "HR", 50000, 30, true),
                new EmployeeP(2, "Bob", "IT", 70000, 28, true),
                new EmployeeP(3, "Charlie", "Finance", 90000, 40, false),
                new EmployeeP(4, "David", "IT", 80000, 35, true),
                new EmployeeP(5, "Eve", "HR", 60000, 25, true));

        //Find all employees who work in the "IT" department.

        employees.stream().filter((emp)-> "IT".equals(emp.getDepartment())).collect(Collectors.toList())
                .forEach(System.out::println);

        //Sort employees by salary in descending order.
        employees.stream().sorted((e1,e2)-> (int) (e2.getSalary()-e1.getSalary())).collect(Collectors.toList())
                .forEach(System.out::println);

        //Find the highest salary in the company.
        System.out.println(employees.stream()
                .max((e1,e2)-> (int) (e1.getSalary()-e2.getSalary())).get().getSalary());

        //Get a list of all active employees.
        employees.stream().filter(e1->e1.isActive()).forEach(System.out::println);

        //Group employees by department.
        System.out.println(employees.stream().collect(Collectors.groupingBy(EmployeeP::getDepartment)));

        //Calculate the average salary of employees in each department.
        employees.stream().collect(Collectors.groupingBy(EmployeeP::getDepartment,Collectors.averagingDouble(EmployeeP::getSalary)))
                .entrySet().forEach(System.out::println);

    }
}
