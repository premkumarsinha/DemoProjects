import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

class Customer {
    String name;
    String city;

    public Customer(String name, String city) {
        this.name = name;
        this.city = city;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "name='" + name + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}

class Transaction {
    int id;
    Customer customer;
    double amount;
    String type; // "DEPOSIT", "WITHDRAWAL"
    LocalDate date;

    public Transaction(int id, Customer customer, double amount, String type, LocalDate date) {
        this.id = id;
        this.customer = customer;
        this.amount = amount;
        this.type = type;
        this.date = date;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", customer=" + customer +
                ", amount=" + amount +
                ", type='" + type + '\'' +
                ", date=" + date +
                '}';
    }
}
public class TransactionStream {

    public static void main(String[] args) {

        List<Customer> customers = Arrays.asList(
                new Customer("Alice", "New York"),
                new Customer("Bob", "Los Angeles"),
                new Customer("Charlie", "New York"),
                new Customer("David", "Los Angeles")
        );

        List<Transaction> transactions = Arrays.asList(
                new Transaction(101, customers.get(0), 500.0, "DEPOSIT", LocalDate.of(2024, 1, 10)),
                new Transaction(102, customers.get(1), 200.0, "WITHDRAWAL", LocalDate.of(2024, 1, 12)),
                new Transaction(103, customers.get(2), 1000.0, "DEPOSIT", LocalDate.of(2024, 2, 1)),
                new Transaction(104, customers.get(3), 300.0, "DEPOSIT", LocalDate.of(2024, 2, 5)),
                new Transaction(105, customers.get(0), 600.0, "WITHDRAWAL", LocalDate.of(2024, 3, 1))
        );

        //Group transactions by city and calculate total transaction amount per city.
        transactions.stream()
                .collect(Collectors.groupingBy(t->t.customer.city, Collectors.summingDouble(t1->t1.amount)))
                .entrySet().forEach(System.out::println);

        //Find the top 2 highest transactions per city.

        // 2️⃣ Find the top 2 highest transactions per city
//        Map<String, List<Transaction>> top2TransactionsByCity = transactions.stream()
//                .collect(Collectors.groupingBy(
//                        txn -> txn.customer.city,
//                        Collectors.collectingAndThen(
//                                Collectors.toList(),
//                                list -> list.stream()
//                                        .sorted((t1, t2) -> Double.compare(t2.amount, t1.amount))
//                                        .limit(2)
//                                        .toList()
//                        )
//                ));

        //Calculate the total deposits vs withdrawals per customer.

//        transactions.stream().
//                collect(Collectors.groupingBy(t1->t1.customer,
//                        Collectors.collectingAndThen(Collectors.toList(),list->list.stream()
//                                .collect(Collectors.groupingBy(t2->t2.type,Collectors.summingDouble(t->t.amount))))))
//                .entrySet().forEach(System.out::println);

        Map<String, Map<String, Double>> depositsVsWithdrawals = transactions.stream()
                .collect(Collectors.groupingBy(
                        txn -> txn.customer.name,
                        Collectors.groupingBy(
                                txn -> txn.type,
                                Collectors.summingDouble(txn -> txn.amount)
                        )
                ));
        System.out.println(depositsVsWithdrawals);


        //Find the month with the highest total transaction value.
        System.out.println(transactions.stream().collect(Collectors.groupingBy(t1->t1.date.getMonth(),Collectors.summingDouble(t1->t1.amount)))
                .entrySet().stream().max((t,t2)-> (int) (t.getValue()-t2.getValue())).get());


        //Sort transactions by date and return only the latest 3 transactions.
        transactions.stream().sorted((t1,t2)->t1.date.compareTo(t2.date)).limit(3)
                .forEach(System.out::println);
    }
}
