import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;

class Order {
    int orderId;
    String customerName;
    double amount;
    boolean isDelivered;

    public Order(int orderId, String customerName, double amount, boolean isDelivered) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.amount = amount;
        this.isDelivered = isDelivered;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public boolean isDelivered() {
        return isDelivered;
    }

    public void setDelivered(boolean delivered) {
        isDelivered = delivered;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return orderId == order.orderId && Double.compare(amount, order.amount) == 0 && isDelivered == order.isDelivered && Objects.equals(customerName, order.customerName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderId, customerName, amount, isDelivered);
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", customerName='" + customerName + '\'' +
                ", amount=" + amount +
                ", isDelivered=" + isDelivered +
                '}';
    }
}

public class ECommerceStream {
    public static void main(String[] args) {

        List<Order> orders = Arrays.asList(
                new Order(101, "John", 250.75, true),
                new Order(102, "Alice", 150.50, false),
                new Order(103, "Bob", 300.40, true),
                new Order(104, "John", 500.00, true),
                new Order(105, "Alice", 200.00, false)
        );

        // Find all delivered orders.
        orders.stream().filter(o->o.isDelivered()).forEach(System.out::println);

        //Find the total revenue from delivered orders.
        System.out.println(orders.stream().filter(o->o.isDelivered())
                .collect(Collectors.summingDouble(Order::getAmount)));

        //Find the customer who spent the most.
        System.out.println(orders.stream().max((o1,o2)-> (int) (o1.getAmount()-o2.getAmount())).get());

        //Group orders by customer.
        orders.stream().collect(Collectors.groupingBy(Order::getCustomerName))
                .entrySet().forEach(System.out::println);

        //Find the average order amount per customer.
        orders.stream().collect(Collectors.groupingBy(Order::getCustomerName, Collectors.averagingDouble(Order::getAmount)))
                .entrySet().forEach(System.out::println);
    }
}
