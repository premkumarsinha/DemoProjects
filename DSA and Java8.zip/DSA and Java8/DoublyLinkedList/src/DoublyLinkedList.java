
public class DoublyLinkedList {

    private ListNode head;
    private ListNode tail;
    private int length;

    private class ListNode{
        private int data;
        private ListNode next;
        private ListNode previous;

        ListNode(int data){
            this.data=data;
        }
    }

    public void createList(){
        ListNode node1=new ListNode(10);
        ListNode node2=new ListNode(20);
        ListNode node3=new ListNode(30);
        ListNode node4=new ListNode(40);
        head=node1;
        node1.next=node2;
        node2.previous=node1;
        node2.next=node3;
        node3.previous=node2;
        node3.next=node4;
        node4.previous=node3;
        tail=node4;
        length=4;
    }

    public void display(){
        ListNode currentNode=head;
        while(currentNode!=null){
            System.out.print(currentNode.data+" -->");
            currentNode=currentNode.next;
        }

        System.out.println("null");
    }

    public int getLength() { return length;}

    public void addNodeAtLast(int value) {
        ListNode newNode=new ListNode(value);
        ListNode temp=tail;

        if(head==null) {
            head = newNode;
            tail = newNode;
        }
        else {
            tail.next=newNode;
            newNode.previous=tail;
            tail=newNode;
        }
        length++;
    }

    public void displayReverse() {
        ListNode temp=tail;

        while(temp!=null) {
            System.out.print(temp.data + " -->");
            temp=temp.previous;
        }
        System.out.println("null");
    }

    public void addNodeAtFirst(int value){
        ListNode newNode=new ListNode(value);

        if(head==null){
            head=newNode;
            tail=newNode;
        }
        else {
            newNode.next=head;
            head.previous=newNode;
            head=newNode;
        }
        length++;
    }

    public void deleteFromStart() throws Exception {
        if(head==null)
            throw new Exception("Linked list is empty");
        else if(head==tail)
            head=tail=null;
        else{
            head=head.next;
            head.previous=null;
        }
        length--;
    }

    public void deleteFromEnd() throws Exception {
        if(head==null)
            throw new Exception("Linked list is empty");
        else if(head==tail)
            head=tail=null;
        else{
            tail=tail.previous;
            tail.next=null;
        }
        length--;
    }

    public void addAtNthPosition(int value,int position) throws Exception {
        ListNode newNode=new ListNode(value);
        ListNode temp=head;
        int counter=1;
        if(position<1||position>length)
            throw new Exception("Invalid position value given");
        else if(position==1)
            addNodeAtFirst(value);
        else{
            while(counter<position-1){
                temp=temp.next;
                counter++;
            }
            newNode.next=temp.next;
            newNode.previous=temp;
            temp.next.previous=newNode;
            temp.next=newNode;
        }

        length++;
    }

    public void deleteAtNthPosition(int position) throws Exception {
        if(position<1||position>length)
            throw new Exception("Invalid position value given");
        else if(position==1)
            deleteFromStart();
        else if(position==length)
            deleteFromEnd();
        else{
            ListNode temp=head;
            int counter=1;
            while(counter<position){
                temp=temp.next;
                counter++;
            }
            temp.previous.next=temp.next;
            temp.next.previous=temp.previous;
        }
        length--;
    }


    public static void main(String[] args) throws Exception {

        DoublyLinkedList dlist=new DoublyLinkedList();
//        dlist.createList();
//        dlist.display();
        dlist.addNodeAtLast(10);
        dlist.addNodeAtLast(20);
        dlist.addNodeAtLast(30);
        dlist.display();
//        dlist.deleteFromEnd();
//        dlist.display();
        dlist.deleteAtNthPosition(3);
        dlist.display();
        dlist.displayReverse();
    }
}